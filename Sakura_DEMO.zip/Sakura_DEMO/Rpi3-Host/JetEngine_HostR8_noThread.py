#!/usr/bin/python

REV_STRING = "R8 w/o Thread. STM32 works non-trasparent"

from time import sleep
from Tkinter import *
import ttk

from PIL import Image
from PIL import ImageDraw
GUI_Sakura_img=Image.new("RGB",(612, 300),"black")

import binascii



import serial
import platform

#define based on different platform.
# 'x86_64'  or 'armv7l'

## not tested under rapsberry-pi yet.

##ser_x86		=	'/dev/ttyS0'
##ser_Rpi		=	'/dev/ttyAMA0'

ser_x64_1		=	'COM11'               ## now. you are on the Windows PC.
ser_x64_2		=	'COM14'               ## now. you are on the Windows PC.
ser_x86 		=	'COM6'               ## now. you are on the Windows PC.
ser_Rpi_1  	        =	'/dev/ttyACM0'      ## since it is a USB>UART
ser_Rpi_2		=	'/dev/ttyACM1'      ## since it is a USB>UART

import sys
import glob
import serial


def serial_ports():
    """ Lists serial port names

        :raises EnvironmentError:
            On unsupported or unknown platforms
        :returns:
            A list of the serial ports available on the system
    """
    if sys.platform.startswith('win'):
        ports = ['COM%s' % (i + 1) for i in range(256)]
    elif sys.platform.startswith('linux') or sys.platform.startswith('cygwin'):
        # this excludes your current terminal "/dev/tty"
        ports = glob.glob('/dev/tty[A-Za-z]*')
	##print ports
    elif sys.platform.startswith('darwin'):
        ports = glob.glob('/dev/tty.*')
    else:
        raise EnvironmentError('Unsupported platform')

    result = []
    for port in ports:
        try:
            s = serial.Serial(port)
            s.close()
            result.append(port)
        except (OSError, serial.SerialException):
            pass
    ##print result
    if sys.platform.startswith('win'):
        return result[len(result)-1]
    elif sys.platform.startswith('linux') or sys.platform.startswith('cygwin'):
        return result[0]        ## ttyACM0  always on the first one



''' want to check if COM11/ COM14 in Windows.
 else  do not open it.
 port2open=serial_ports()
 if sys.platform.startswith('win'):
	 if (int (port2open[len(port2open)-2:len(port2open)]) >=10):
        	raise EnvironmentError('Please plug STM32 USB>UART')
	        exit()

if sys.platform.startswith('win'):
    if (serial_ports() < "COM11"):
        raise EnvironmentError('Please plug STM32 USB>UART')
        exit()
elif sys.platform.startswith('linux') or sys.platform.startswith('cygwin'):
    if (serial_ports() > "/dev/ttyACM1"):
        raise EnvironmentError('Please plug STM32 USB>UART')
        exit()
'''
comport2open = serial_ports()

###comport2open = 'COM4'
ser = serial.Serial(
	port=comport2open, 
	baudrate=115200,
	timeout = 0.6)

ser.flushInput()
ser.flushOutput()


import time
import csv

HOST2STM32_HEADER   =   '\t'        # CTRL-I
SLAVE2STM32_HEADER  =   '\v'        # CTRL-K

Write2              =   '!'
FetchIn             =   '@'
TESTING_VHP_ON      =    HOST2STM32_HEADER +Write2+ "Vo\r"
TESTING_VHP_OFF     =    HOST2STM32_HEADER +Write2+ "Vf\r"
CR  = '\r'
LF  = '\n'

PRINTING_TEST       =    HOST2STM32_HEADER +Write2+ "m001\r"
ABORT_PRINTING      =    HOST2STM32_HEADER +Write2+ "KOOL\r"
##NOZZLE_TEST         =    HOST2STM32_HEADER +Write2+ "m002\r"
PRINTING_PATTERN    =    HOST2STM32_HEADER +Write2+ "m002\r"
PRINTING_PATm003    =    HOST2STM32_HEADER +Write2+ "m003\r" 
PRINTING_PATm004    =    HOST2STM32_HEADER +Write2+ "m004\r"

## ======= RPI  LINE1/2/3 Mailboxs =========================================
SetRPI2_LINE1       =    HOST2STM32_HEADER +Write2+ "L001\r" 
SetRPI2_LINE2       =    HOST2STM32_HEADER +Write2+ "L002\r" 
SetRPI2_LINE3       =    HOST2STM32_HEADER +Write2+ "L003\r"

## RPI2 system commands
## ======= RPI  SHTUDOWN command =========================================
SetRPI2_SHUTDOWN    =    HOST2STM32_HEADER +Write2+ ">SHUTDOWN\r"

## ======= RPI  date/time setup command ===================================
SetRPI2_date    =    HOST2STM32_HEADER +Write2+ ">date -s '20161020'\r"
## ======= RPI  date/time setup command ===================================
SetRPI2_time    =    HOST2STM32_HEADER +Write2+ ">date -s '13:00:00'\r"

'''

'''

GETIN               =    HOST2STM32_HEADER + FetchIn
GetPrintingStatus   =    GETIN +"p\r"
GetPulseWidth       =    GETIN +"P\r"           ## 2 digits back
GetDwell            =    GETIN +"T\r"           ## 3 digits
GetEncoder          =    GETIN +"E\r"           ## 4 digits
GetVHP              =    GETIN +"V\r"           ## 2 digits
GetIDSet            =    GETIN +"I\r"           ## 3 digits
GetREV              =    GETIN +"r\r"           ## ?? len of the following format


FW_REVISION         =    "Oct  4 2016  18:12:33"        ## a string used to calculated the len of it.

GetEnccoderNow      =    GETIN +"e\r"           ## 4 digits

ASK_RPI2_PRINT      =    Write2 +"go\r"
QUERY_RPI2_READY    =    FetchIn +"ready?\r"

## ======= RPI  STATUS  ==================================================
##  1 byte = 8 bits  7,6,5,4  3,2,1,0
##                   bit7 = 1   :  Rpi2 not received yet.
##                        = 0   :  Rpi2 mailbox received.

GetRPI2_STATUS      =    GETIN +"@R\r"          ## \t@@R 


flag4printgo        =    False

def everytime_check():
    ser.close()
    try:
            ser.open()
    except Exception, e:
            print "error open serial port: " + str(e)
            exit()
    
        
def readback():
    everytime_check()
    if ser.isOpen():

        ser.write(GetVHP)
        readback= ser.read(2)
        print(" VH: %02d" % int(readback,16))
        VHP_volt.set(int(readback,16))
            
        ser.write(GetPulseWidth)
        readback= ser.read(2)
        ##print readback
        print(" PulsewWidth %02X" % int(readback,16))
        pulseWidth.set(int(readback,16))



        ser.write(GetDwell)
        readback= ser.read(3)
        print(" Dwell: %03X" % int(readback,16))
        dwell.set(int(readback,16))

        ##root.after(1000, countdown, count-1)
        ser.write(GetEncoder)
        readback= ser.read(4)
        print(" Encoder: %04X" % int(readback,16))
        ##??
            
        ser.write(GetIDSet)
        readback= ser.read(3)
        print(" IDSet: %03X" % int(readback,16))
        ##??

        ser.write(GetREV)
        readback= ser.read(len(FW_REVISION))
        print("r: %s" %readback)
        sakura_line5.delete(0, END)
        sakura_line5.insert (0, "r: " +readback)
    
        ser.close()
        ##frame.update()

def getNow():
    everytime_check()
    if ser.isOpen():    
        ##root.after(1000, countdown, count-1)
        ser.write(GetEnccoderNow)
        readback= ser.read(4)
        print(" Encoder Now: %04X" % int(readback,16))    
        ser.close()

def printTest():            ## program about !m001
    everytime_check()
    if ser.isOpen():
            ser.write(TESTING_VHP_ON)
            print(TESTING_VHP_ON)
            time.sleep(1)       ## has to wait the power-up
            ser.write(PRINTING_TEST)
            print(PRINTING_TEST)
            ##time.sleep(1)
            ser.close()

def printPattern():     ## program !m002
    everytime_check()
    if ser.isOpen():
            ser.write(TESTING_VHP_ON)
            print(TESTING_VHP_ON)
            time.sleep(1)       ## has to wait the power-up
            ser.write(PRINTING_PATTERN)
            print(PRINTING_PATTERN)
            ##time.sleep(1)
            ser.close()
    
def printAbort():
    everytime_check()
    if ser.isOpen():
            ser.write(ABORT_PRINTING)
            print(ABORT_PRINTING)
            ##time.sleep(1)
            ser.close()
            
def printODD():      ## program about !m003
    everytime_check()
    if ser.isOpen():
            ser.write(TESTING_VHP_ON)
            print(TESTING_VHP_ON)
            time.sleep(1)       ## has to wait the power-up
            ser.write(PRINTING_PATm003)
            ser.close()

def printEVEN():      ## program about !m004
    everytime_check()
    if ser.isOpen():
            ser.write(TESTING_VHP_ON)
            print(TESTING_VHP_ON)
            time.sleep(1)       ## has to wait the power-up
            ser.write(PRINTING_PATm004)
            ser.close()
'''    
def VHP_BLINK():
    everytime_check()
    if ser.isOpen():
            ser.write(TESTING_VHP_OFF)
            print(TESTING_VHP_OFF)
            time.sleep(1)
            ser.write(TESTING_VHP_ON)
            print(TESTING_VHP_ON)
            time.sleep(1.5)
            ser.close()
'''
            
def VHP_OFF():
    everytime_check()
    if ser.isOpen():
        ser.write(TESTING_VHP_OFF)
        print(TESTING_VHP_OFF)
        ser.close()

def VHP_ON():
    everytime_check()
    if ser.isOpen():
            ser.write(TESTING_VHP_ON)
            print(TESTING_VHP_ON)
            ser.close()
        
'''def read_status1():
    everytime_check()
    if ser.isOpen():
            ser.write(GetPrintingStatus)
            print "local message:"
            time.sleep(0.8)
            print(ser.readline())


        
def JetDriver_init():
        Vhp_volt.set(14)
        pulseWidth.set(28)
        dwell.set(1000)
'''
v_table = [6.1, 6.4, 6.8, 7.2,
           7.5, 7.7, 8.0, 8.5,
           8.7, 9.0, 9.3, 9.5,
           9.8, 10.0,10.3,10.5,
           10.6, 10.7,11.0,  11.1,
           11.3, 11.4, 11.5, 11.7,
           11.8, 11.9, 12.0, 12.0,
           12.1, 12.1, 12.1, 12.2 ]
def change_VHP(new_data):
    everytime_check()
    ser.write( HOST2STM32_HEADER +Write2)
    tmpString = "%02X" % int(new_data)
    ser.write( 'VH' + tmpString + CR )
    ## f=(int(new_data)*0.335+6.1)  ## does not mapp correct.
    ## use a table look up.
    ##print "VH set %02.1f"%(v_table[int(new_data)])
    newLabel = "VH: %02.1f"% (v_table[int(new_data)])
    vhLabel.set(newLabel)
    ser.close()

##SetRPI2_date    =    HOST2STM32_HEADER +Write2+ ">date -s '20161020'\r"

def sendRpi2_date(bb):
    everytime_check()
    ser.write( HOST2STM32_HEADER +Write2)
    tmpString = ">date -s '%s%s%s'"% (bb[0:4], bb[5:7], bb[8:10])
    ser.write( ' ' + tmpString + CR )
    ser.close()

##SetRPI2_time    =    HOST2STM32_HEADER +Write2+ ">date -s '13:00:00'\r"

def sendRpi2_time(bb):
    everytime_check()
    ser.write( HOST2STM32_HEADER +Write2)
    tmpString = ">date -s '%s'"% (bb[11:19])
    ser.write( ' ' + tmpString + CR )
    ser.close()
    
def change_pulseWidth(new_data):
    everytime_check()
    ser.write( HOST2STM32_HEADER +Write2)
    tmpString = "%02X" % int(new_data)
    ser.write( 'P' + tmpString + CR )
    f =(int(new_data)+3) *4 *20.8
    ##print "pulseWidth set %d = %f ns"%(int(new_data), f )
    newLabel= "pulseW:%04.0f ns" % f
    pw.set(newLabel)
    ##print newLabel
    ser.close()
        
def change_dwell(new_data):
    everytime_check()
    ser.write( HOST2STM32_HEADER +Write2)
    tmpString = "%03X" % int(new_data)
    ser.write( 'T' + tmpString + CR )
    f =int(new_data) 
    ##print "dwell= %04d us"%(int(new_data))
    newLabel= "%04d us" % f
    dw.set(newLabel)
    ser.close()
        

def change_encoder(new_data):
    everytime_check()
    ser.write( HOST2STM32_HEADER +Write2)
    tmpString = "%04X" % int(new_data)
    ser.write( 'E' + tmpString + CR )
    f =int(new_data) 
    newLabel= "Encoder:%05d " % f
    enclabel.set(newLabel)
    ser.close()
    
def Parameter_Set():
    everytime_check()
    if ser.isOpen():
            change_VHP(Vhp_volt)
            #change T parameter
            change_pulseWidth(pulseWidth)
            change_dwell(dwell)
            ser.close()

def  slowlygo():
        flag4printgo = True
        
def close_and_quit():
    ##thread.stop()
    ##global root
    if ser.isOpen():

        ser.close()
        sleep(1.0)      ## wait thread ## but FAILed.
    print "Windows Closed"
    root.destroy()
    root.quit()
    
#creat the main window 
root = Tk()
root.title('_________JetEnginer4Sakura Testing Platform____'+ REV_STRING)
root.geometry('700x365')

#creat Frame for grid and widgets 
frame=ttk.Frame(root)
    
myQuit=Button(frame, text='Quit', command=close_and_quit)
##b.grid (column=0, row=Row_number)

#creat Start button
##blink=Button(frame,text='VHP_ON_OFF',command=VHP_BLINK)

#creat VHP_ON button
vhp_on=Button(frame,text='VHP_ON',command=VHP_ON)

#creat VHP_OFF button
vhp_off=Button(frame,text='VHP_OFF',command=VHP_OFF)

#creat printTest  button
printtest=Button(frame,text='PrintTest m001',command=printTest)

#creat AbortPrint  button
printabort=Button(frame,text='Abort Print',command=printAbort)

#creat NozzleCheckPrint  button
##printnozzle=Button(frame,text='Nozzle Print',command=printNozzle)

#creat printTest  button
printpattern=Button(frame,text='PrintTest m002',command=printPattern)

#creat printm003  button
printm003=Button(frame,text='p m003',command=printODD)

#creat printm004  button
printm004=Button(frame,text='p m004',command=printEVEN)

#creat status button
## status1=Button(frame,text='status1',command=read_status1)


#creat Parm_set button
parm_set=Button(frame,text='Parameter set',command=Parameter_Set)

#create readback button
readback =Button(frame,text='Read back ',command=readback)


# create slowGo button
slowGo = Button (frame, text='go SLOW', command = slowlygo)

Row_number=0

#creat VHP_volt widget
VHP_volt=IntVar()
VHP_volt.set(14)
VHP_VOLT=Scale(frame,orient=HORIZONTAL,length=135,sliderlength=5,sliderrelief='raised',
             from_=0x00,to=0x1f,resolution=1,variable=VHP_volt,command=change_VHP)

Row_number=Row_number+1

vhLabel=StringVar()
vhLabel.set('VHP')
Label(frame,textvariable=vhLabel).grid(column=0,row=Row_number,sticky=SE)
VHP_VOLT.grid(column=1,row=Row_number,columnspan=4,sticky=W)

#creat pulseWidth widget
pulseWidth=IntVar()
pulseWidth.set(24)
pulseWIDTH=Scale(frame,orient=HORIZONTAL,length=135,sliderlength=5,sliderrelief='raised',
             from_=0x0A,to=0x25,resolution=1,variable=pulseWidth,command=change_pulseWidth)
Row_number=Row_number+1

pw=StringVar()
pw.set('pulseWidth')
Label(frame,textvariable=pw ).grid(column=0,row=Row_number,sticky=SE)
pulseWIDTH.grid(column=1,row=Row_number,columnspan=4,sticky=W)


## create dwell   widget
dwell=IntVar()
dwell.set(500)
dwellTime=Scale(frame,orient=HORIZONTAL,length=160,sliderlength=5,sliderrelief='raised',
             from_=26,to=0xFFF,resolution=1,variable=dwell,command=change_dwell)
Row_number=Row_number+1

dw=StringVar()
dw.set('dwell')
Label(frame,textvariable=dw ).grid(column=0,row=Row_number,sticky=SE)
dwellTime.grid(column=1,row=Row_number,columnspan=4,sticky=W)


## create Encoder (trigger point)  widget
encoder =IntVar()
encoder.set(500)
encoderVAR=Scale(frame,state=DISABLED,orient=HORIZONTAL,length=200,sliderlength=5,sliderrelief='raised',
             from_=0x00,to=0xFFFF,resolution=1,variable= encoder,command=change_encoder)
Row_number=Row_number+1

enclabel=StringVar()
enclabel.set('encoder')
Label(frame,textvariable=enclabel ).grid(column=0,row=Row_number,sticky=SE)
encoderVAR.grid(column=1,row=Row_number,columnspan=4,sticky=W)

#display all widgets
frame.grid(column=0,row=0)


Row_number=Row_number+1
Label(frame,text='').grid(column=0,row=Row_number,sticky=W)


# display all buttons
Row_number=Row_number+1
Label(frame,text='').grid(column=0,row=Row_number,sticky=W)
printm003.grid(column=2, row=Row_number, sticky=E)
printm004.grid(column=3, row=Row_number, sticky=E)
Row_number=Row_number+1

##blink.grid(column=0,row=Row_number,sticky=E)

## status1.grid(column=1,row=Row_number,sticky=E)

#printnozzle.grid(column=2, row=Row_number, sticky=W)
printabort.grid(column=1, row=Row_number, sticky=E)
printtest.grid(column=2, row=Row_number, sticky=E)
printpattern.grid(column=3, row=Row_number, sticky=E)
    
Row_number=Row_number+1

vhp_on.grid(column=1, row=Row_number, sticky=E)
readback.grid(column=2, row=Row_number, sticky=E)
vhp_off.grid(column=3, row=Row_number, sticky=E)

Row_number=Row_number+1

slowGo.grid(column=0, row=Row_number, sticky=E)


Label(frame,text='').grid(column=0,row=Row_number,sticky=W)

Row_number=Row_number+1
myQuit.grid(column=3, row=Row_number+1, sticky=E)
Label(frame,text=comport2open).grid(column=0,row=Row_number,sticky=W)
Label(frame,text="<firmware rev").grid(column=3,row=Row_number,sticky=W)



KEYLINE		=	"SAKURA_SCRIBE_TIJ"
READY2GO        =       "RPI2_READY_to_GO!"


sakura_line1 =Entry (frame)
sakura_line2 =Entry (frame)
sakura_line3 =Entry (frame)
sakura_line5 =Entry (frame)

sakura_line5.grid (column=2, row=Row_number)

sakura_line1.grid (column=1, row=Row_number)
Row_number=Row_number+1
sakura_line2.grid (column=1, row=Row_number)

Row_number=Row_number+1
sakura_line3.grid (column=1, row=Row_number)

Row_number=Row_number+1

sakura_line1.insert (10, "SP15-999999")
sakura_line2.insert (10, "SMITH MARY")
sakura_line3.insert (0,  "A1")
##sakura_line5.insert (0, READY2GO)


root.protocol("WM_DELETE_WINDOW", close_and_quit)




# make our own buffer
# useful for parsing commands from Rpi2
# DO NOT to use the Serial.readline.  It hangs.

serBuffer = ""

printonce = True

def readRpi2R2():
    global printonce
    if (printonce): print "Yes thread is running"
    printonce = False
    
    everytime_check()
    global ser
    while True:
        if ser.isOpen():
            ##if (ser.in_waiting > 0):
            ##    ser.flushInput()
            try:
                c = ser.readline() # attemp to read
            except (OSError, serial.SerialException):
                print " Slave query Error"
                pass
            
            '''c =""
            count =0
            for c0 in ser.read():
                c += c0
                count+=1
                if ((c0=='\n') or (c0=='\r')):
                    print count
                    break
            '''
            ##print "read %d length" %len(c)
            ##print "compared KEYLINE %d length" %len(KEYLINE)
            ##print "what the hell you are? %s" %c
            if (19==len(c)):
                ##print binascii.hexlify(c)
                c= c.replace("\n","")
                ##print binascii.hexlify(c)
                c= c.replace("\r","")
                ##print binascii.hexlify(c)
            
            if (KEYLINE==c):
                ##print "BINGO,YOU have REACH here !!"
                ser.write(sakura_line1.get()+"\r\n")     ## try to feed
                print sakura_line1.get()
                ##sleep(1.5)
                ser.write(sakura_line2.get()+"\r\n")     ## try to feed
                ##sleep(1.5)
                print sakura_line2.get()
                ser.write(sakura_line3.get()+"\r\n")     ## try to feed
                print sakura_line3.get()
            if (READY2GO==c):
                if (flag4printgo):
                    sakura_line5.insert (0, READY2GO)
                    ser.write(sakura_line5.get()+"\r\n")     ## now you go..
                    flag4printgo=False                      ## and reset that
                
            ##else:
              ##  print "something hit %s" %c
            ##ser.close()   ## not in thread to close.

def readRpi2R5():
    global printonce
    if (printonce): print "Yes thread is running"
    printonce = False
    
    everytime_check()
    global ser
    if ser.isOpen():
        ser.write(GetRPI2_STATUS)
        readback= ser.read(2)
        print(" RPI2 Status: %02X" % int(readback,16))


def countdown(count):
    # change text in label        
    label['text'] = count
    global thread
    if count > 0:
        # call countdown again after 1000ms (1s)
        root.after(1000, countdown, count-1)
    else:
        ##readRpi2R5()
        getNow()
        root.after(250, countdown, count)
        
label = Label(root)
label.place(x=35, y=315)

everytime_check()
if ser.isOpen():
    ser.flushInput()
    ser.flushOutput()
    ##sleep(1)
    ##thread = threading.Thread(target=readRpi2R2, args=(ser,))
    ##sleep(1)
    print "thread starts? no"
    ##thread.start()

countdown(1)
root.mainloop()
