## echo " Originally copied from MainTask.sh"
## echo " modified to let it go on the Rpi2 boot-up"

cd ~
cd sketch
cd Release2Sakura

echo "Now use your serial console input"
python serial4barcode.py
python execute_program.py
echo "Now you should  download the bitmap into JetDriver-STM32"

##echo "Now you could see what you want"
##gpicview /tmp/text.png

