import csv
import sys

nozzleMap  = [['0' for i in range(14)] for j in range(22)]
              
f=open('nozzleMapper.csv', 'rb')
try:
    reader = csv.reader(f)
    rownum=0
    for row in reader:
        if (0==rownum) :
            header = row
            #print "HEADER :%s" %header
        else:
            colnum=0
            for col in row[1:] :
                nozzleMap[colnum][rownum-1]=int(col)
                ##print ('%s: %s' % (header[colnum+1], col))
                ##print colnum
                ##print row[colnum]
                colnum+=1
        rownum+=1
        if(rownum>14):
            break
        
    ##print row

finally:
    f.close()


print(nozzleMap)   # then print out for check
# then, remember the spatial magic number: 97
# so. the spatial-encoding could go.
# when EVEN
