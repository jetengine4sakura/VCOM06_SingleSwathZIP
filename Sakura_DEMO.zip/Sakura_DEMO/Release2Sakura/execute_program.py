#!/usr/bin/python
import subprocess
subprocess.call (["iec16022", "-f", "PNG", "-i", "/tmp/input.txt", "-o", "/tmp/barcode2D.png"])
subprocess.call (["mogrify", "-scale", "130x130","/tmp/barcode2D.png"])
subprocess.call (["python", "text_gen3.py"])


