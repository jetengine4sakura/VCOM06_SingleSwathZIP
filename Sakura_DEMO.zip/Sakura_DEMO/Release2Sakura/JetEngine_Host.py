from Tkinter import *
import ttk

from PIL import Image
from PIL import ImageDraw
GUI_Sakura_img=Image.new("RGB",(612, 300),"black")

#!/usr/bin/python

import serial
import platform

#define based on different platform.
# 'x86_64'  or 'armv7l'

## not tested under rapsberry-pi yet.

##ser_x86		=	'/dev/ttyS0'
##ser_Rpi		=	'/dev/ttyAMA0'

##ser_x86		=	'COM11'               ## now. you are on the Windows PC.
ser_x86		=	'COM14'               ## now. you are on the Windows PC.
##ser_x86		=	'COM6'               ## now. you are on the Windows PC.
ser_Rpi		=	'/dev/ttyUSB0'      ## since it is a USB>UART
##ser_Rpi		=	'/dev/ttyUSB1'      ## since it is a USB>UART

##if ('x86_64'==platform.uname()[4]):
if ('AMD64'==platform.uname()[4]):
	ser2open = ser_x86
else:
	ser2open = ser_Rpi

ser = serial.Serial(
	port=ser2open, 
	baudrate=115200,
	timeout = 3.0)



import time
import csv

HOST2STM32_HEADER   =   '\t'        # CTRL-I
SLAVE2STM32_HEADER  =   '\v'        # CTRL-K

Write2              =   '!'
FetchIn             =   '@'
TESTING_VHP_ON      =    HOST2STM32_HEADER +Write2+ "Vo\r"
TESTING_VHP_OFF     =    HOST2STM32_HEADER +Write2+ "Vf\r"
CR  = '\r'
LF  = '\n'

PRINTING_TEST       =    HOST2STM32_HEADER +Write2+ "map\r"

GETIN               =    HOST2STM32_HEADER + FetchIn
GetPrintingStatus   =    GETIN +"p\r"
GetPulseWidth       =    GETIN +"P\r"           ## 2 digits back
GetDwell            =    GETIN +"T\r"           ## 3 digits
GetEncoder          =    GETIN +"E\r"           ## 4 digits
GetVHP              =    GETIN +"V\r"           ## 2 digits
GetIDSet            =    GETIN +"I\r"           ## 3 digits

def readback():
    ser.close()
    try:
            ser.open()
    except Exception, e:
            print "error open serial port: " + str(e)
            exit()
    if ser.isOpen():
            ser.write(GetPulseWidth)
            readback= ser.read(2)
            print(" Pulsewidth %02X" % int(readback,16))
            
            ser.write(GetEncoder)
            readback= ser.read(4)
            print(" Encoder: %04X" % int(readback,16))

            ser.write(GetIDSet)
            readback= ser.read(3)
            print(" IDSet: %03X" % int(readback,16))

            ser.write(GetDwell)
            readback= ser.read(3)
            print(" IDSet: %03X" % int(readback,16))

            ser.close()

        
def printTest():
    ser.close()
    try:
            ser.open()
    except Exception, e:
            print "error open serial port: " + str(e)
            exit()
    if ser.isOpen():
            ser.write(TESTING_VHP_ON)
            print(TESTING_VHP_ON)
            time.sleep(1)       ## has to wait the power-up
            ser.write(PRINTING_TEST)
            print(PRINTING_TEST)
            time.sleep(1.5)
            ser.close()

        
def VHP_BLINK():
    ser.close()
    try:
            ser.open()
    except Exception, e:
            print "error open serial port: " + str(e)
            exit()
    if ser.isOpen():
            ser.write(TESTING_VHP_OFF)
            print(TESTING_VHP_OFF)
            time.sleep(1)
            ser.write(TESTING_VHP_ON)
            print(TESTING_VHP_ON)
            time.sleep(1.5)

            ser.close()
def VHP_OFF():
    ser.close()
    try:
            ser.open()
    except Exception, e:
            print "error open serial port: " + str(e)
            exit()
    if ser.isOpen():
            ser.write(TESTING_VHP_OFF)
            print(TESTING_VHP_OFF)
            ser.close()

def VHP_ON():
    ser.close()
    try:
            ser.open()
    except Exception, e:
            print "error open serial port: " + str(e)
            exit()
    if ser.isOpen():
            ser.write(TESTING_VHP_ON)
            print(TESTING_VHP_ON)
            ser.close()
        
def read_status1():
    ser.close()
    try:
            ser.open()
    except Exception, e:
            print "error open serial port: " + str(e)
            exit()
    if ser.isOpen():
            ser.write(GetPrintingStatus)
            print "local message:"
            time.sleep(0.8)
            print(ser.readline())


'''        
def JetDriver_init():
        Vhp_volt.set(14)
        pulseWidth.set(28)
        dwell.set(1000)
'''        
def change_VHP(new_data):
    ser.close()
    try:
        ser.open()
    except Exception, e:
        print "error open serial port: " + str(e)
        exit()
    ser.write( HOST2STM32_HEADER +Write2)
    tmpString = "%02X" % int(new_data)
    ser.write( 'VH' + tmpString + CR )
    print "VH set %d"%( int(new_data))
    ser.close()
        
def change_pulseWidth(new_data):
    ser.close()
    try:
        ser.open()
    except Exception, e:
        print "error open serial port: " + str(e)
        exit()
    ser.write( HOST2STM32_HEADER +Write2)
    tmpString = "%02X" % int(new_data)
    ser.write( 'P' + tmpString + CR )
    f =(int(new_data)-1) *4 *20.8
    print "pulseWidth set %d = %f ns"%(int(new_data), f )
    newLabel= "%04.0f ns" % f
    pw.set(newLabel)
    print newLabel
    ser.close()
        
def change_dwell(new_data):
    ser.close()
    try:
        ser.open()
    except Exception, e:
        print "error open serial port: " + str(e)
        exit()
    ser.write( HOST2STM32_HEADER +Write2)
    tmpString = "%03X" % int(new_data)
    ser.write( 'T' + tmpString + CR )
    f =int(new_data) 
    ##print "dwell= %04d us"%(int(new_data))
    newLabel= "%04d us" % f
    dw.set(newLabel)
    ser.close()
        

def change_encoder(new_data):
    ser.close()
    try:
        ser.open()
    except Exception, e:
        print "error open serial port: " + str(e)
        exit()
    ser.write( HOST2STM32_HEADER +Write2)
    tmpString = "%04X" % int(new_data)
    ser.write( 'E' + tmpString + CR )
    f =int(new_data) 
    newLabel= "%05d ticks" % f
    enclabel.set(newLabel)
    ser.close()
    
def Parameter_Set():
    ser.close()
    try:
            ser.open()
    except Exception, e:
            print "error open serial port: " + str(e)
            exit()
    if ser.isOpen():
            change_VHP(Vhp_volt)
            #change T parameter
            change_pulseWidth(pulseWidth)
            change_dwell(dwell)
            ser.close()
            
    
#creat the main window 
root = Tk()
root.title('_________JetEnginer4Sakura Testing Platform_________')
root.geometry('700x350')

#creat Frame for grid and widgets 
frame=ttk.Frame(root)
    

#creat Start button
start=Button(frame,text='VHP_ON_OFF',command=VHP_BLINK)

#creat VHP_ON button
vhp_on=Button(frame,text='VHP_ON',command=VHP_ON)

#creat VHP_OFF button
vhp_off=Button(frame,text='VHP_OFF',command=VHP_OFF)

#creat printTest  button
printtest=Button(frame,text='PrintTest',command=printTest)

#creat status button
status1=Button(frame,text='status1',command=read_status1)


#creat Parm_set button
parm_set=Button(frame,text='Parameter set',command=Parameter_Set)

#create readback button
readback =Button(frame,text='Read back ',command=readback)



Row_number=0

#creat VHP_volt widget
VHP_volt=IntVar()
VHP_volt.set(14)
VHP_VOLT=Scale(frame,orient=HORIZONTAL,length=135,sliderlength=5,sliderrelief='raised',
             from_=0x00,to=0x1f,resolution=1,variable=VHP_volt,command=change_VHP)

Row_number=Row_number+1

Label(frame,text='VHP').grid(column=0,row=Row_number,sticky=SE)
VHP_VOLT.grid(column=1,row=Row_number,columnspan=4,sticky=W)

#creat pulseWidth widget
pulseWidth=IntVar()
pulseWidth.set(28)
pulseWIDTH=Scale(frame,orient=HORIZONTAL,length=135,sliderlength=5,sliderrelief='raised',
             from_=0x0A,to=0x25,resolution=1,variable=pulseWidth,command=change_pulseWidth)
Row_number=Row_number+1

pw=StringVar()
pw.set('pulseWidth')
Label(frame,textvariable=pw ).grid(column=0,row=Row_number,sticky=SE)
pulseWIDTH.grid(column=1,row=Row_number,columnspan=4,sticky=W)


## creat dwell   widget
dwell=IntVar()
dwell.set(500)
dwellTime=Scale(frame,orient=HORIZONTAL,length=160,sliderlength=5,sliderrelief='raised',
             from_=26,to=0xFFF,resolution=1,variable=dwell,command=change_dwell)
Row_number=Row_number+1

dw=StringVar()
dw.set('dwell')
Label(frame,textvariable=dw ).grid(column=0,row=Row_number,sticky=SE)
dwellTime.grid(column=1,row=Row_number,columnspan=4,sticky=W)


## creat Encoder (trigger point)  widget
encoder =IntVar()
encoder.set(500)
encoderVAR=Scale(frame,orient=HORIZONTAL,length=200,sliderlength=5,sliderrelief='raised',
             from_=0x00,to=0xFFFF,resolution=1,variable= encoder,command=change_encoder)
Row_number=Row_number+1

enclabel=StringVar()
enclabel.set('encoder')
Label(frame,textvariable=enclabel ).grid(column=0,row=Row_number,sticky=SE)
encoderVAR.grid(column=1,row=Row_number,columnspan=4,sticky=W)

#display all widgets
frame.grid(column=0,row=0)


Row_number=Row_number+1
Label(frame,text='').grid(column=0,row=Row_number,sticky=W)


Row_number=Row_number+1
Label(frame,text='').grid(column=0,row=Row_number,sticky=W)
Row_number=Row_number+1

start.grid(column=1,row=Row_number,sticky=W)

status1.grid(column=3,row=Row_number,sticky=W)

printtest.grid(column=5, row=Row_number, sticky=E)

Row_number=Row_number+1
vhp_on.grid(column=1, row=Row_number, sticky=E)
readback.grid(column=3, row=Row_number, sticky=E)
vhp_off.grid(column=5, row=Row_number, sticky=E)


##chip_initial()
frame.mainloop()
