#!/usr/bin/python

import serial
import platform

#define based on different platform.
# 'x86_64'  or 'armv7l'

## not tested under rapsberry-pi yet.

file2write	=	'/tmp/input.txt'	# for execute_program to read.
ser_x86		=	'/dev/ttyS0'
ser_Rpi		=	'/dev/ttyAMA0'

if ('x86_64'==platform.uname()[4]):
	ser2open = ser_x86
else:
	ser2open = ser_Rpi

ser = serial.Serial(
	port=ser2open, 
	baudrate=115200,
	timeout = 10.0)

f               =	open (file2write, 'wb')
lines_length    =    [11, 2,2 ]
##1ine1_length    =       11     ## at least
##line2_length    =       2      ## at least 
##line3_length    =       2
questions       =  [" Patient Num ", " Patient Name ", "Class :>"]
rcv             =  ["", "",""]
KEYLINE		=	"SAKURA_SCRIBE_TIJ"

print("===Serial4barcode input===")

while True:
        ser.write("\r\n")       ## a clean line
	ser.write(KEYLINE)	## a KEYLINE to tell host.
        ser.write("\r\n")       ## a clean line
	ready2next      =       3      ## at least, 3 times pass
        for i in range(3):
                ser.write(questions[i])
                rcv[i] = ser.readline()
                ##if (0!=len(rcv[i])):
		ser.write(":"+ rcv[i])   ## echo back to see what you input.
		##ser.write("\r\n len:%02d"%len(rcv) )
                if  ((len(rcv[i])>0) and (lines_length[i]<len(rcv[i]))):
                                ready2next = ready2next -1 
        if (0==ready2next):
                for i in range(3):
                        f.write(rcv[i])   ## only that  rcv[:len(rcv)-2] ?
                f.close()
                ser.write("\n\rJobs done\r\n")
                print ("Jobs done.")
		ser.close()
                break    # jobs done.
        else:
                print("Type in Error")
		ser.write("Type in Error\n\r")
        ## if all_condition meet,
	## go to next step:  execute_program to generate barcode.

##sys.exit(0)
##if __name__ == "__main__":
##	main()
