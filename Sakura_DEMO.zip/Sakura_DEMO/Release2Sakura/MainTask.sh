echo "Now use your serial console input"
python serial4barcode.py
python execute_program.py
echo "Now you could see what you want"
gpicview /tmp/text.png

