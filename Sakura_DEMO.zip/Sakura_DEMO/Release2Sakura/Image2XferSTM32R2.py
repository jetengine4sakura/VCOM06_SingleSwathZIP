#!/usr/bin/python
import csv
import sys
##  Revision 2,  send all data to STM32.
##  command it for a very slow printing.

nozzleMap  = [['0' for i in range(14)] for j in range(22)]
              
f=open('nozzleMapper.csv', 'rb')
try:
    reader = csv.reader(f)
    rownum=0
    for row in reader:
        if (0==rownum) :
            header = row
            #print "HEADER :%s" %header
        else:
            colnum=0
            for col in row[1:] :
                nozzleMap[colnum][rownum-1]=int(col)
                ##print ('%s: %s' % (header[colnum+1], col))
                ##print colnum
                ##print row[colnum]
                colnum+=1
        rownum+=1
        if(rownum>14):
            break
        
    ##print row

finally:
    f.close()


##print(nozzleMap)   # then print out for check
# then, remember the spatial magic number: 97
# so. the spatial-encoding could go.
# when EVEN

from PIL import Image
## constants defines
IUT300_NOZZLES_NUM  =   308		## because of table-entries is 308
WidthOfBuffers      =   612
NumOfBuffers        =   32
MagicNumber         =   97
swathNumber         =   WidthOfBuffers + MagicNumber

TO_Rpi2_Header      =   "EP0W"
SetRpi2_WorkIndex   =   "EP0S"
Rpi2_Read_Header    =   "EP0R"


TO_STM32            =   ""
file2write          =   "/tmp/ToSTM32R2.txt"
image2read          =   "/tmp/text.png"

## Just assign a free index for demo
demoIndex           =   0x13

##pMAX                =   13      ## if  Odd nozzles only.
pMAX                =   14
aMAX                =   22      ## 22 Address lines
pStart              =   1
    
def validPixel(x,y):
	global MagicNumber
	brightness=0
	if (0==y%2):	## even pixel
		if (x>=WidthOfBuffers):
			return 0		## no pixels there
		else:	
			xy = (x,y)		
			R,G,B = im.getpixel(xy) ##wLine, translated
		   	brightness = sum([R,G,B])/3  ## 0 is dark (black) and 255 is bright (white)
		
	else:		## odd pixel
		if (x<MagicNumber):
			return 0
		else:
			xy = ((x-MagicNumber), y)
			R,G,B = im.getpixel(xy) ##wLine, translated
		   	brightness = sum([R,G,B])/3  ## 0 is dark (black) and 255 is bright (white)
	return brightness	
	
def swathExtract(wLine):        ## working Line 0~ 612
    thatByte = 0
    global IUT300_NOZZLES_NUM
    global im                   # im-age
    global f                    # file to write
    writtenWords = 0
    aIndex  =   1
    pIndex  =   pStart          # if we capture Odd nozzles (pStart=1) else (pStart=2)
    while (aIndex<=aMAX):
        # Get RGB
        ##print " swath :%03d"%swath,
        ##print " wLine :%03d"%wLine
        ##== org == xy = (wLine, swath)
        y_translated=nozzleMap[aIndex-1][pIndex-1]
	if (0== y_translated):
		brightness=0;	## no pixel there
	else:
		brightness = validPixel(wLine, y_translated-1)
#####################################################################
        thisBit = brightness;
        if (thisBit>128): thatBit=1
        else:
            thatBit=0

        whichBit = (pIndex-1)%16

        if (0==whichBit):
            thatByte=0
            
        ## cumulative collect bits
        thatByte = thatByte | (thatBit<<whichBit)

#####################################################################
        ## == org ==   if (7==whichBit):
        if (13==whichBit):       ## only collect 14 bits as 1 word
            f.write("%04X"%thatByte)
	    writtenWords+=1
        pIndex += 1
        if (pIndex>pMAX):
            pIndex = pStart
            aIndex += 1
            ##if (aIndex>aMAX):
              ##  aIndex =1

    ##f.write("%04X"%thatByte)
    ##f.write("00\n") # output.println(hex(0,2)) // to form 312 bits stream, compatible with IUT308
    f.write("\n")
    ##print("writtenWord(decimal) %03d"%writtenWords)

def setupEP0(index2buf):            ## index2buf,  just a pointer to which index (0~31)
    global f
    if (NumOfBuffers<=index2buf):
        raise ValueError('index larger than buffer %02X'%index2buf) 
    f = open (file2write, 'wb')
    TO_Rpi2 = TO_Rpi2_Header + "%02X"%index2buf
    f.write(TO_Rpi2);
    ##for i in range(0, WidthOfBuffers):
    for i in range(0, swathNumber ):		## now it changes, including MagicNumber inside.
        swathExtract(wLine=i)
    f.flush()
    f.close()
    print ("file :" + file2write + " was created")


STM32Command4PrintGO    =   "\v!g"




import serial
import platform
import os
import time

#define based on different platform.
# 'x86_64'  or 'armv7l'

## not tested under rapsberry-pi yet.

ser_x86		=	'/dev/ttyS0'
ser_Rpi		=	'/dev/ttyAMA0'

ONLY_ASCII	=	True

if ('x86_64'==platform.uname()[4]):
	ser2open = ser_x86
else:
	ser2open = ser_Rpi

ser = serial.Serial(
	port=ser2open, 
	baudrate=115200, bytesize=8,
	timeout = 10.0)

## --- real-time (not so real/fast time )  to send swath to STM32.
## calculated: 115200 ~ 11520 bytes/s.
##  then   22bytes per-swath (only EVEN or ODD nozzles ).
##   will send as  523 lines /second.
##   SAKURA only provides  612 lines.
##   therefore  1second ~ (more) will finish the DEMO.
##
def  goPrintgo():
    f2read = open (file2write)     ## file2write ? Now it changes to file2read.
    line = f2read.readline()
    if (False==(os.path.isfile(file2write))):
        raise ValueError("File can't open")
    L0 = len(TO_Rpi2_Header)
    EP0IN = line[:L0]
    if (EP0IN==TO_Rpi2_Header): print(TO_Rpi2_Header + " matched, Bingo!!")
    indexStr=line[L0:(L0+2)]
    print "index String: %s" % indexStr
    index2buf = 0x1F & int(indexStr,16)
    print "parsed index2buf :%02X" %index2buf


    ## ask STM32 go into printDemo mode
    ser.write(STM32Command4PrintGO +"%04X"%swathNumber +'\n')
    time.sleep (0.3)		## let it parse. It takes some time.

    ## prepare a swath line
    for swathByte in range(44):   ##  EVEN / ODD nozzles   included

	byteIndex=L0+2+(swathByte*2)
        thatByte=line[byteIndex: byteIndex+2]
        thisByte=int(thatByte,16)
	if (ONLY_ASCII):
            ser.write(thatByte)
	else:
	        if ('x86_64'==platform.uname()[4]):
        	    ser.write(thatByte)	    ## 2 digits
	        else:
        	    ser.write(thisByte)     ## pure binary

    for i in range(1, swathNumber):
        line = f2read.readline()
        for swathByte in range(44):
	    byteIndex=     (swathByte*2)
            thatByte=line[byteIndex: byteIndex+2]
            thisByte=int(thatByte,16)
	if (ONLY_ASCII):
            ser.write(thatByte)
	else:
	        if ('x86_64'==platform.uname()[4]):
        	    ser.write(thatByte)
	        else:
        	    ser.write(thisByte)     ## pure binary
                                           
    ##print ("index2buf :%02X"%index2buf + " ready")
    f2read.close()


def main():
    global im
    im= Image.open(image2read)
    setupEP0(demoIndex)     # to generate /tmp/ToRpi.txt
    goPrintgo()

if __name__ == '__main__':
    main()
    
